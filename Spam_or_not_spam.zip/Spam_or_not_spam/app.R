## app.R ##
library(shiny)
library(ggplot2)
library(dplyr)
library(DT)
library(readr)
library(tm)
library(wordcloud)
library(memoise)
library(janeaustenr)
library(tidyverse)
library(tidytext)
library(wordcloud2)
library(shinycssloaders)
library(janeaustenr)
library(tidyr)
library(igraph)
library(ggraph)
library(plotly)
spam_or_not_spam2 <- read_csv("data/spam_or_not2.csv", 
                              col_types = cols(label = col_character()))

spam_or_not_spam2["label"][spam_or_not_spam2["label"] == "0"] <- "ham"
spam_or_not_spam2["label"][spam_or_not_spam2["label"] == "1"] <- "spam"

#spam_or_not_spam2 = subset(spam_or_not_spam2, "NUMBER")


ui <- fluidPage(
  titlePanel("Visualization of Spam and Ham Email Messages", windowTitle = "Ham or spam"),
  helpText("ITB8812 Andmete visualiseerimine (Virumaa). Author: Ivan Švaiger"),
  br(),
  tabsetPanel(  
    tabPanel("Introduction",
             sidebarLayout(
               sidebarPanel(img(src = "images.gif", height = 175, width = 350)),
               mainPanel(h2("Project description"),
                         p("Within the general framework of this project, a visual comprehensive representation of the dataset 'Spam or Not Spam' is being performed, dedicated to the problem of classifying which email messages, are spam and which are non-spam (ham).
The main purpose of the visualisation presented in this project is to provide an insight into both the dataset as a whole, as well as the spam origins, and word patterns most often used by spammers and non-spammers.", p(),
                           "For these purposes, the following research tasks have been set:", p(), "1. Data was pre-processed to be visually appealing", p(), "2. The most relevant text visualization tools were identified and applied to the dataset used in this project.", p(), "3. An interactive web application has been created that shows visualized results that represent the most important aspects among the vast amount of information. " ),
                         br(),
                         h2("Dataset"),
                         p("The 'Spam or Not Spam dataset' for this project is extracted from Kaggle data repositories and available from the " , a(href = "https://www.kaggle.com/ozlerhakan/spam-or-not-spam-dataset", "LINK"), "The dataset consists of two attributes: «email» and class attribute «label» and contains emails collected from Apache SpamAssassin anti-spam platform. 
                         Using the entire pre-processed dataset of 2871  records when deploying to shinyapps.io environment results in a system error: 'Out of memory'. Thus, for the most stable work of this application, 1400 records (emails) were randomly selected from the original dataset. Also, the word 'NUMBER' was removed from the dataset because it is a stop word."),
                         br(),
                         h2("Application overview"),
                         p("Tab 1: Distribution & Table – Overview of the entire dataset using barplot checking the distribution of type of messages and data table."),
                         p("Tab 2: Wordcloud – Visual representations of words that appear more frequently."),
                         p("Tab 3: Unigram – Top 10 frequent word in Unigram matrix."),
                         p("Tab 4: Bigrams network – Bigram relation graph between pair of words."),
               ) )),
                 tabPanel("Distribution & Table",
                          tags$style(type="text/css",
                                     ".shiny-output-error { visibility: hidden; }",
                                     ".shiny-output-error:before { visibility: hidden; }"
                          ),
                          plotlyOutput("dist",height = "700px")%>% withSpinner(),
                          
                          h3("Datatable"),
                          dataTableOutput("tdist")%>% withSpinner()
                 ),
                 tabPanel("Wordcloud",
                          sidebarLayout(
                            sidebarPanel(
                              uiOutput("spamham"),
                              
                              uiOutput("frequency"),
                              
                              uiOutput("maximum")
                              )
                            ,
                            mainPanel(
                              tags$style(type="text/css",
                                         ".shiny-output-error { visibility: hidden; }",
                                         ".shiny-output-error:before { visibility: hidden; }"
                              ),
                              uiOutput("word",width="100%",height="850px")%>% withSpinner()
                            )
                 )
                          ),
                 tabPanel("Unigram",
                          sidebarLayout(
                            sidebarPanel(
                              uiOutput("spamham2")
                            )
                          ,
                          mainPanel( tags$style(type="text/css",
                                                ".shiny-output-error { visibility: hidden; }",
                                                ".shiny-output-error:before { visibility: hidden; }"
                          ),
                            plotlyOutput("bigr",height = "750px")%>% withSpinner()
                          )
                          )
                 ),
                 tabPanel("Bigrams network",
                          sidebarLayout(
                            sidebarPanel(
                              uiOutput("spamham3")
                            )
                          ,
                          mainPanel(
                            tags$style(type="text/css",
                                       ".shiny-output-error { visibility: hidden; }",
                                       ".shiny-output-error:before { visibility: hidden; }"
                            ),
                            plotOutput("ggraphh",height = "750px")%>% withSpinner()
                          ))
                 )
                 )
                 
)


server <- function(input, output) {
  output$dist<-renderPlotly({
    
    df<-data.frame(table(spam_or_not_spam2$label))
    colnames(df)<-c("Type","Frequency")
    # Overlaid histograms
    p<-ggplot(df, aes(x=Type, y=Frequency, fill=Type,text = paste("Type: ", Type,
                                                                  "<br> Frequency :", Frequency))) +
      geom_bar(stat="identity")+theme_minimal()
    ggplotly(p,tooltip = "text")%>%
      layout(
        xaxis = list(tickfont = list(size = 15)), 
        yaxis = list(tickfont = list(size = 15)))
  })
  output$tdist<-renderDataTable({
    
    #df<-data.frame(table(spam_or_not_spam2$label))
    #colnames(df)<-c("Type","Frequency")
    datatable(spam_or_not_spam2,options = list(pageLength=2))
    
  })
  output$spamham<-renderUI({
    
    
      selectInput("selection", "Choose spam or ham:",
                  choices = unique(spam_or_not_spam2$label),
                  selected = unique(spam_or_not_spam2$label),
                  multiple = T
      )
    
    
  })
  output$spamham2<-renderUI({
    
    
    selectInput("selection2", "Choose spam or ham:",
                choices = unique(spam_or_not_spam2$label),
                selected = unique(spam_or_not_spam2$label),
                multiple = T
    )
    
    
  })
  output$spamham3<-renderUI({
    
    
    selectInput("selection3", "Choose spam or ham:",
                choices = unique(spam_or_not_spam2$label),
                selected = unique(spam_or_not_spam2$label),
                multiple = T
    )
    
    
  })
  smoh<-reactive({
    spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection)
    spam_or_not_spam2
  })
  smoh2<-reactive({
    spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection2)
    spam_or_not_spam2
  })
  smoh3<-reactive({
    spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection3)
    spam_or_not_spam2
  })
  df<-reactive({
    
    #Create a vector containing only the text
    #spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection)
    dt<-smoh()
    text <- dt$email
    # Create a corpus  
    docs <- Corpus(VectorSource(text))
    
    
    docs <- docs %>%
      tm_map(removeNumbers) %>%
      tm_map(removePunctuation) %>%
      tm_map(stripWhitespace)
    docs <- tm_map(docs, content_transformer(tolower))
    docs <- tm_map(docs, removeWords, stopwords("english"))
    
    
    dtm <- TermDocumentMatrix(docs) 
    matrix <- as.matrix(dtm) 
    words <- sort(rowSums(matrix),decreasing=TRUE) 
    #words<-words[-1]
    df <- data.frame(word = names(words),freq=words)
    
  })
  output$maximum<-renderUI({
    
      subs<-subset( df(),  df()$freq >=input$freq )
      
      sliderInput("max",
                  "Maximum Number of Words:",
                  min = 2,  max = nrow(subs),  value =nrow(subs),step=1 )
    
  })
  df2<-reactive({
    #Create a vector containing only the text
    #spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection)
    dt<-smoh2()
    text <- dt$email
    # Create a corpus  
    docs <- Corpus(VectorSource(text))
    
    
    docs <- docs %>%
      tm_map(removeNumbers) %>%
      tm_map(removePunctuation) %>%
      tm_map(stripWhitespace)
    docs <- tm_map(docs, content_transformer(tolower))
    docs <- tm_map(docs, removeWords, stopwords("english"))
    
    
    dtm <- TermDocumentMatrix(docs) 
    matrix <- as.matrix(dtm) 
    words <- sort(rowSums(matrix),decreasing=TRUE) 
    df <- data.frame(word = names(words),freq=words)
    
  })
  output$maximum<-renderUI({
    
    subs<-subset( df(),  df()$freq >=input$freq )
    
    sliderInput("max",
                "Maximum Number of Words:",
                min = 1,  max = 200,  value =20,step=1 )
    
  })
  output$frequency<-renderUI({
      sliderInput("freq",
                  "Minimum Frequency:",
                  min = 1,  max =200, value = 20,step=1)
    
   
    
  })
  output$bigr<-renderPlotly({
    
    #data_frame(txt = spam_or_not_spam2$email) %>%
    # unnest_tokens(bigram, txt, token = "ngrams", n = 2) %>%
    #count(bigram, sort = TRUE) %>%
    #top_n(15) %>%
    #ggplot(aes(fct_reorder(bigram, n), n)) +
    #geom_col() +
    #coord_flip() +
    #labs(x = NULL)
    #> Selecting by n
    df<-na.omit(df2())
    #df<-subset(df, word != "number")
    
    p<-ggplot(data=df[1:10,], aes(x=reorder(word, desc(-freq)), y=freq,text = paste("word: ", word,
                                                                                       "<br> frequency :", freq))) +
      geom_bar(stat="identity",fill="steelblue")+ coord_flip()+ theme_minimal()
    ggplotly(p +ggtitle("Top 10") +
      xlab("Words") + ylab("Frequency")+theme(text = element_text(size = 15)),tooltip = "text")%>%
      layout(
        xaxis = list(tickfont = list(size = 15)), 
        yaxis = list(tickfont = list(size = 15))) 
  })
  
  
  
  
  
  output$wordcloud2<-renderWordcloud2({
    
    #subs<-subset( df(),  df()$freq >=input$freq )
    #subs<-subs[1:input$max,]
    wordcloud2(df()[1:input$max,],size = 4)
    #wordcloud(words = df()$word, freq = df()$freq, min.freq = input$freq,max.words=input$max, random.order=FALSE, rot.per=0.35,            colors=brewer.pal(8, "Dark2"))
  })
  #output$word <- renderUI({
   # if (input$max == 1) {
    #  strong("The frequency parameter or the maximum number of words are too high, try other parameters")
    #}
    #else{
     # wordcloud2(df()[1:input$max, ],size=4)
    #}
  #})
  output$word<- renderUI({
    if (req(input$max) == 1) {
      wordcloud2(rbind(c(word = NA, freq = 0L), df()[1:input$max, ]))
    }
    else{
      wordcloud2(df()[1:input$max, ])
    }
  })
  output$ggraphh<-renderPlot({
    #spam_or_not_spam2 <-subset( spam_or_not_spam2,  spam_or_not_spam2$label %in% input$selection)
    dt<-smoh3()
    sm<-dt %>%
      unnest_tokens(bigram, email, token = "ngrams", n = 2) %>%
      separate(bigram, c("word1", "word2"), sep = " ") %>%
      select(-label) -> bigrams_separated
    
    sm_filtered <- sm %>%
      filter(!word1 %in% stop_words$word) %>%
      filter(!word2 %in% stop_words$word)
    
    # new bigram counts:
    sm_counts <- sm_filtered %>% 
      count(word1, word2, sort = TRUE)
    #sm_counts<-subset(sm_counts, word1 != "number")
    #sm_counts<-subset(sm_counts, word2 != "number")
    
    
    
    bigram_graph <- sm_counts %>%
      filter(n > 20) %>%
      graph_from_data_frame()
    set.seed(204211)
    
    a <- grid::arrow(type = "closed", length = unit(.15, "inches"))
    
    ggraph(bigram_graph, layout = "fr") +
      geom_edge_link(aes(edge_alpha = n), show.legend = TRUE,
                     arrow = a, end_cap = circle(.07, 'inches')) +
      geom_node_point(color = "lightblue", size = 5) +
      geom_node_text(aes(label = name), vjust = 1, hjust = 1) +
      theme_void()
  })
}


shinyApp(ui, server)